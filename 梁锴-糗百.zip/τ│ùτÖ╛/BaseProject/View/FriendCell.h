//
//  FriendCell.h
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LKImageView.h"
@interface FriendCell : UITableViewCell

//* 头像图片 */
@property(nonatomic,strong)LKImageView *iconIV;

//* 性别图片 */
@property(nonatomic,strong)LKImageView *MwIV;

/** 昵称标签 */
@property (nonatomic, strong) UILabel *nameLb;

/** 年龄标签 */
@property (nonatomic, strong) UILabel *ageLb;

//* 正文标签 */
@property(nonatomic,strong)UILabel *contentLb;

//* 地址标签 */
@property(nonatomic,strong)UILabel *locationLb;

//* 点赞标签 */
@property(nonatomic,strong)UILabel *likeNumLb;

/** 点赞图标 */
@property (nonatomic, strong) UIButton *likeIV;

//* 评论数标签 */
@property(nonatomic,strong)UILabel *clicksNumLb;

/** 评论图标 */
@property (nonatomic, strong) UIButton *clicksIV;

//* 正文图片 */
@property(nonatomic,strong)LKImageView *contentIV;

@property (nonatomic, assign) BOOL is;

@end
