//
//  LKImageView.h
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LKImageView : UIView
@property(nonatomic,strong)UIImageView *imageView;
@end
