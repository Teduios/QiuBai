//
//  QiuShiVideoCell.m
//  BaseProject
//
//  Created by apple on 15/11/19.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiVideoCell.h"
////为播放视频引入的类库
//#import <AVKit/AVKit.h>
//#import <AVFoundation/AVFoundation.h>


@implementation QiuShiVideoCell

//初始一个播放器控制器，使用单例模式，限制同一时间只能播放一个视频
+ (AVPlayerViewController *)shareInstance{
    static AVPlayerViewController *playerVC = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        playerVC = [AVPlayerViewController new];

        
        
    });
    return playerVC;
}

//* 头像图片 */
- (LKImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[LKImageView alloc] init];
        _iconIV.layer.cornerRadius=20;
    }
    return _iconIV;
}

//* 视频内容图片
- (LKImageView *)contentIV {
    if(_contentIV == nil) {
        _contentIV = [[LKImageView alloc] init];
        _contentIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _contentIV;
}

//* 热门图片 */
- (LKImageView *)HotIV {
    if(_HotIV == nil) {
        _HotIV = [[LKImageView alloc] init];
        UIImageView *imageView = [UIImageView new];
        imageView.image = [UIImage imageNamed:@"UMS_account_tap_white"];
        [_HotIV setImageView:imageView];
    }
    return _HotIV;
}

/** 昵称标签 */
- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.font = [UIFont systemFontOfSize:14];
        _nameLb.textColor = [UIColor lightGrayColor];
    }
    return _nameLb;
}

/** 正文标签 */
- (UILabel *)contentLb {
    if(_contentLb == nil) {
        _contentLb = [[UILabel alloc] init];
        _contentLb.font = [UIFont systemFontOfSize:14];
        _contentLb.numberOfLines = 0;
    }
    return _contentLb;
}

/** 点赞标签 */
- (UILabel *)likeNumLb {
    if(_likeNumLb == nil) {
        _likeNumLb = [[UILabel alloc] init];
        _likeNumLb.font = [UIFont systemFontOfSize:12];
        _likeNumLb.textColor = [UIColor lightGrayColor];
    }
    return _likeNumLb;
}
/** 评论数标签 */
- (UILabel *)clicksNumLb {
    if(_clicksNumLb == nil) {
        _clicksNumLb = [[UILabel alloc] init];
        _clicksNumLb.font = [UIFont systemFontOfSize:12];
        _clicksNumLb.textColor = [UIColor lightGrayColor];
    }
    return _clicksNumLb;
}
/** 分享标签 */
- (UILabel *)shareNumLb {
    if(_shareNumLb == nil) {
        _shareNumLb = [[UILabel alloc] init];
        _shareNumLb.font = [UIFont systemFontOfSize:12];
        _shareNumLb.textColor = [UIColor lightGrayColor];
    }
    return _shareNumLb;
}

/** 播放按钮 */
- (UIButton *)playButton{
    if (!_playButton) {
        _playButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        _playButton.backgroundColor = [UIColor yellowColor];
        [_playButton setImage:[UIImage imageNamed:@"video_list_cell_big_icon"] forState:UIControlStateNormal];
        //点击按钮，播放视频
        [_playButton bk_addEventHandler:^(id sender) {
            //初始化一个播放器
            AVPlayer *player = [AVPlayer playerWithURL:self.videoURL];
            //开始播放视频
            [player play];
            [QiuShiVideoCell shareInstance].player = player;
            //将播放控制器的视图添加到视频截图上
            [self.contentIV addSubview:[QiuShiVideoCell shareInstance].view];
            
            [[QiuShiVideoCell shareInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
                
                make.center.mas_equalTo(self.contentIV);
                make.size.mas_equalTo(self.contentIV);
            }];
            
            
            
        } forControlEvents:UIControlEventTouchUpInside];

        
    }
    return _playButton;
}

//如果正在播放视频的cell被复用了，需要将其cell上播放器上删除掉
- (void)prepareForReuse{
    [super prepareForReuse];
    
    //判断当前cell是否播放，如果有则删除
    if ([QiuShiVideoCell shareInstance].view.superview == self.imageView || [QiuShiVideoCell shareInstance].player != nil) {
        [[QiuShiVideoCell shareInstance].view removeFromSuperview];
        [QiuShiVideoCell shareInstance].player = nil;
        
    }

}

//笑脸
- (UIButton *)smileBtn {
    if(_smileBtn == nil) {
        _smileBtn = [[UIButton alloc] init];
        [_smileBtn setImage:[UIImage imageNamed:@"smile"] forState:UIControlStateNormal];
        //        _smileBtn.backgroundColor = [UIColor redColor];
    }
    return _smileBtn;
}
//伤心
- (UIButton *)cryBtn {
    if(_cryBtn == nil) {
        _cryBtn = [[UIButton alloc] init];
        [_cryBtn setImage:[UIImage imageNamed:@"cry"] forState:UIControlStateNormal];
        
    }
    return _cryBtn;
}
//消息
- (UIButton *)messageBtn {
    if(_messageBtn == nil) {
        _messageBtn = [[UIButton alloc] init];
        [_messageBtn setImage:[UIImage imageNamed:@"msg"] forState:UIControlStateNormal];
        
    }
    return _messageBtn;
}
//分享
- (UIButton *)shareBtn {
    if(_shareBtn == nil) {
        _shareBtn = [[UIButton alloc] init];
        [_shareBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
        
    }
    return _shareBtn;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconIV];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.HotIV];
        [self.contentView addSubview:self.contentLb];
        [self.contentView addSubview:self.contentIV];
        [self.contentView addSubview:self.likeNumLb];
        [self.contentView addSubview:self.clicksNumLb];
        [self.contentIV addSubview:self.playButton];
        
        
        [self.contentView addSubview:self.smileBtn];
        [self.contentView addSubview:self.cryBtn];
        [self.contentView addSubview:self.messageBtn];
        [self.contentView addSubview:self.shareBtn];

        //头像
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        
        //昵称
        [self.nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.centerY.mas_equalTo(self.iconIV.mas_centerY);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(self.HotIV.mas_left).mas_equalTo(-100);
        }];
        
        //热门或者新鲜
        [self.HotIV mas_makeConstraints:^(MASConstraintMaker *make) {
            //            make.right.mas_equalTo(-10);
            make.size.mas_equalTo(CGSizeMake(45, 45));
            make.left.mas_equalTo(self.nameLb.mas_right).mas_equalTo(10);
            make.centerY.mas_equalTo(self.nameLb);
        }];
        
        //内容
        [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_greaterThanOrEqualTo(20);
            //            make.height.mas_lessThanOrEqualTo(20);
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.iconIV.mas_bottomMargin).mas_equalTo(15);
            make.right.mas_equalTo(-10);
        }];
        
        // 视频内容图片
        [self.contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(300);
            make.top.mas_equalTo(self.contentLb.mas_bottom).mas_equalTo(15);
        }];
        
        [self.playButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.contentIV.mas_centerX);
            make.centerY.mas_equalTo(self.contentIV.mas_centerY);
            make.size.mas_equalTo(CGSizeMake(130, 130));
        }];

        //笑脸
        [self.likeNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(60, 25));
//            make.bottom.mas_equalTo(-10);
            make.top.mas_equalTo(self.contentIV.mas_bottom).mas_equalTo(15);
        }];
        
        //评论
        [self.clicksNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(60, 25));
            make.centerY.mas_equalTo(self.likeNumLb);
            make.left.mas_equalTo(self.likeNumLb.mas_rightMargin).mas_equalTo(20);
        }];
        
        //        //分享
        //        [self.shareNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
        //            make.centerY.mas_equalTo(self.clicksNumLb);
        //            make.size.mas_equalTo(CGSizeMake(60, 25));
        //            make.left.mas_equalTo(self.clicksNumLb.mas_rightMargin).mas_equalTo(20);
        //
        //        }];
        [self.smileBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.top.mas_equalTo(self.likeNumLb.mas_bottom).mas_equalTo(25);
            make.left.mas_equalTo(30);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.cryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.left.mas_equalTo(self.smileBtn.mas_right).mas_equalTo(40);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.messageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.left.mas_equalTo(self.cryBtn.mas_right).mas_equalTo(40);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(33, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.right.mas_equalTo(self.contentLb.mas_right);
            make.bottom.mas_equalTo(-10);
        }];

        
    }
    
    return self;
}


@end
