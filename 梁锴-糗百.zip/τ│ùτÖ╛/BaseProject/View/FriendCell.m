//
//  FriendCell.m
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FriendCell.h"

@implementation FriendCell

//* 头像图片 */
- (LKImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[LKImageView alloc] init];
        _iconIV.layer.cornerRadius=25;
    }
    return _iconIV;
}

//* 性别图片 */
- (LKImageView *)MwIV {
    if(_MwIV == nil) {
        _MwIV = [[LKImageView alloc] init];
        UIImageView *imagView = [[UIImageView alloc] init];
        
        imagView.image = [UIImage imageNamed:@"boy"];
        
        UIImageView *imagView1 = [[UIImageView alloc] init];
        
        imagView1.image = [UIImage imageNamed:@"girl"];
        _MwIV.imageView = self.is ? imagView:imagView1;
    }
    return _MwIV;
}

/** 昵称标签 */
- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.font = [UIFont systemFontOfSize:13];
        _nameLb.textColor = [UIColor lightGrayColor];
    }
    return _nameLb;
}

/** 正文标签 */
- (UILabel *)contentLb {
    if(_contentLb == nil) {
        _contentLb = [[UILabel alloc] init];
        _contentLb.font = [UIFont systemFontOfSize:13];
        _contentLb.numberOfLines = 0;
    }
    return _contentLb;
}

/** 点赞标签 */
- (UILabel *)locationLb {
    if(_locationLb == nil) {
        _locationLb = [[UILabel alloc] init];
        _locationLb.font = [UIFont systemFontOfSize:12];
        _locationLb.textColor = [UIColor lightGrayColor];
    }
    return _locationLb;
}
/** 评论数标签 */
- (UILabel *)likeNumLb {
    if(_likeNumLb == nil) {
        _likeNumLb = [[UILabel alloc] init];
        _likeNumLb.font = [UIFont systemFontOfSize:12];
        _likeNumLb.textColor = [UIColor lightGrayColor];
    }
    return _likeNumLb;
}
/** 分享标签 */
- (UILabel *)clicksNumLb {
    if(_clicksNumLb == nil) {
        _clicksNumLb = [[UILabel alloc] init];
        _clicksNumLb.font = [UIFont systemFontOfSize:12];
        _clicksNumLb.textColor = [UIColor lightGrayColor];
    }
    return _clicksNumLb;
}

/** 点赞图标 */
- (UIButton *)likeIV {
    if(_likeIV == nil) {
        _likeIV = [[UIButton alloc] init];
        _likeIV.size = CGSizeMake(15, 15);
        ///设置按钮正常状态下的
        [_likeIV setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        
        //设置被选中状态的图片
        [_likeIV setImage:[UIImage imageNamed:@"info@3x"] forState:UIControlStateSelected];
    }
    return _likeIV;
}

/** 评论图标 */
- (UIButton *)clicksIV {
    if(_clicksIV == nil) {
        _clicksIV = [[UIButton alloc] init];
        _clicksIV.size = CGSizeMake(15, 15);
        [_clicksIV setImage:[UIImage imageNamed:@"clicks"] forState:UIControlStateNormal];
        
        //设置被选中状态的图片
        [_clicksIV setImage:[UIImage imageNamed:@"info@3x"] forState:UIControlStateSelected];
    }
    return _clicksIV;
}
    

- (LKImageView *)contentIV {
    if(_contentIV == nil) {
        _contentIV = [[LKImageView alloc] init];
        _contentIV.contentMode = 1;
    }
    return _contentIV;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconIV];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.MwIV];
        [self.contentView addSubview:self.contentLb];
        [self.contentView addSubview:self.ageLb];
        [self.contentView addSubview:self.likeNumLb];
        [self.contentView addSubview:self.clicksNumLb];
        [self.contentView addSubview:self.locationLb];
        
        [self.contentView addSubview:self.likeIV];
        [self.contentView addSubview:self.clicksIV];
        [self.contentView addSubview:self.contentIV];
        
        //头像
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        //昵称
        [self.nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.mas_equalTo(15);
            make.centerY.mas_equalTo(self.iconIV.mas_centerY);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(10);
            make.width.mas_equalTo(100);
        }];
        //性别
        [self.MwIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(45, 20));
            make.left.mas_equalTo(self.nameLb.mas_right).mas_equalTo(10);

            make.top.mas_equalTo(20);
        }];
        
        //内容
        [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_greaterThanOrEqualTo(20);
            make.left.mas_equalTo(self.nameLb.mas_left);
            make.top.mas_equalTo(self.iconIV.mas_bottomMargin).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
        
        [self.contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.nameLb.mas_left);
            make.top.mas_equalTo(self.contentLb.mas_bottom).mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(150, 150));
        }];
        
        
        //位置
        [self.locationLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentLb.mas_left);
            make.size.mas_equalTo(CGSizeMake(100, 25));
            make.top.mas_equalTo(self.contentIV.mas_bottom).mas_equalTo(15);
            make.bottom.mas_equalTo(-10);
        }];
        
        
        
        //点赞图标
        [self.likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(20, 20));
            make.centerY.mas_equalTo(self.locationLb);
            make.right.mas_equalTo(self.likeNumLb.mas_left).mas_equalTo(-10);
        }];
        
        //点赞标签
        [self.likeNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(self.locationLb);
            make.right.mas_equalTo(self.clicksIV.mas_left).mas_equalTo(-30);
        }];
        
        //评论图标
        [self.clicksIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(20, 20));
            make.centerY.mas_equalTo(self.locationLb);
        //评论标签
            make.right.mas_equalTo(self.clicksNumLb.mas_left).mas_equalTo(-10);
        }];

        [self.clicksNumLb mas_makeConstraints:^(MASConstraintMaker *make) {

            make.centerY.mas_equalTo(self.locationLb);
            make.right.mas_equalTo(-20);
        }];
        
        
    }
    
    
    /*
     //点赞图标
     [self.likeIV mas_makeConstraints:^(MASConstraintMaker *make) {
     make.size.mas_equalTo(CGSizeMake(15, 15));
     make.centerY.mas_equalTo(self.locationLb);
     make.left.mas_equalTo(self.locationLb.mas_rightMargin).mas_equalTo(170);
     }];
     
     //点赞标签
     [self.likeNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
     //            make.size.mas_equalTo(CGSizeMake(60, 25));
     make.centerY.mas_equalTo(self.likeIV);
     make.left.mas_equalTo(self.likeIV.mas_rightMargin).mas_equalTo(10);
     }];
     
     //评论图标
     [self.clicksIV mas_makeConstraints:^(MASConstraintMaker *make) {
     make.size.mas_equalTo(CGSizeMake(15, 15));
     make.centerY.mas_equalTo(self.likeNumLb);
     //评论标签
     make.left.mas_equalTo(self.likeNumLb.mas_rightMargin).mas_equalTo(20);
     }];
     
     [self.clicksNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
     
     make.centerY.mas_equalTo(self.clicksIV);
     make.left.mas_equalTo(self.clicksIV.mas_rightMargin).mas_equalTo(10);
     }];
    */
    return self;
}


@end
