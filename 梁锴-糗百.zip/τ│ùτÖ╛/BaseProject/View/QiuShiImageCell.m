//
//  QiuShiImageCell.m
//  BaseProject
//
//  Created by apple on 15/11/16.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiImageCell.h"

@implementation QiuShiImageCell

//* 头像图片 */
- (LKImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[LKImageView alloc] init];
        _iconIV.layer.cornerRadius=20;
    }
    return _iconIV;
}

//* 内容图片
- (LKImageView *)contentIV {
    if(_contentIV == nil) {
        _contentIV = [[LKImageView alloc] init];
        _contentIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _contentIV;
}

//* 热门图片 */
- (LKImageView *)HotIV {
    if(_HotIV == nil) {
        _HotIV = [[LKImageView alloc] init];
        _HotIV.imageView.image = [UIImage imageNamed:@"hot"];
    }
    return _HotIV;
}

/** 昵称标签 */
- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.font = [UIFont systemFontOfSize:14];
        _nameLb.textColor = [UIColor lightGrayColor];
    }
    return _nameLb;
}

/** 正文标签 */
- (UILabel *)contentLb {
    if(_contentLb == nil) {
        _contentLb = [[UILabel alloc] init];
        _contentLb.font = [UIFont systemFontOfSize:14];
        _contentLb.numberOfLines = 0;
    }
    return _contentLb;
}

/** 点赞标签 */
- (UILabel *)likeNumLb {
    if(_likeNumLb == nil) {
        _likeNumLb = [[UILabel alloc] init];
        _likeNumLb.font = [UIFont systemFontOfSize:12];
        _likeNumLb.textColor = [UIColor lightGrayColor];
    }
    return _likeNumLb;
}
/** 评论数标签 */
- (UILabel *)clicksNumLb {
    if(_clicksNumLb == nil) {
        _clicksNumLb = [[UILabel alloc] init];
        _clicksNumLb.font = [UIFont systemFontOfSize:12];
        _clicksNumLb.textColor = [UIColor lightGrayColor];
    }
    return _clicksNumLb;
}
/** 分享标签 */
- (UILabel *)shareNumLb {
    if(_shareNumLb == nil) {
        _shareNumLb = [[UILabel alloc] init];
        _shareNumLb.font = [UIFont systemFontOfSize:12];
        _shareNumLb.textColor = [UIColor lightGrayColor];
    }
    return _shareNumLb;

    
}

//笑脸
- (UIButton *)smileBtn {
    if(_smileBtn == nil) {
        _smileBtn = [[UIButton alloc] init];
        [_smileBtn setImage:[UIImage imageNamed:@"smile"] forState:UIControlStateNormal];
        //        _smileBtn.backgroundColor = [UIColor redColor];
    }
    return _smileBtn;
}
//伤心
- (UIButton *)cryBtn {
    if(_cryBtn == nil) {
        _cryBtn = [[UIButton alloc] init];
        [_cryBtn setImage:[UIImage imageNamed:@"cry"] forState:UIControlStateNormal];
        
    }
    return _cryBtn;
}
//消息
- (UIButton *)messageBtn {
    if(_messageBtn == nil) {
        _messageBtn = [[UIButton alloc] init];
        [_messageBtn setImage:[UIImage imageNamed:@"msg"] forState:UIControlStateNormal];
        
    }
    return _messageBtn;
}
//分享
- (UIButton *)shareBtn {
    if(_shareBtn == nil) {
        _shareBtn = [[UIButton alloc] init];
        
        [_shareBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
        
    }
    return _shareBtn;
}


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.iconIV];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.HotIV];
        [self.contentView addSubview:self.contentLb];
        [self.contentView addSubview:self.contentIV];
        [self.contentView addSubview:self.likeNumLb];
        [self.contentView addSubview:self.clicksNumLb];
        
        
        [self.contentView addSubview:self.smileBtn];
        [self.contentView addSubview:self.cryBtn];
        [self.contentView addSubview:self.messageBtn];
        [self.contentView addSubview:self.shareBtn];

        //头像
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        
        //昵称
        [self.nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.centerY.mas_equalTo(self.iconIV.mas_centerY);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(self.HotIV.mas_left).mas_equalTo(-100);
        }];
        
        //热门或者新鲜
        [self.HotIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(45, 45));
            make.left.mas_equalTo(self.nameLb.mas_right).mas_equalTo(10);
            make.centerY.mas_equalTo(self.nameLb);
        }];
        
        //内容
        [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_greaterThanOrEqualTo(20);
            //            make.height.mas_lessThanOrEqualTo(20);
            make.left.mas_equalTo(10);
            make.top.mas_equalTo(self.iconIV.mas_bottomMargin).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
        // 内容图片
        [self.contentIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.height.mas_equalTo(300);
//            make.size.mas_equalTo(CGSizeMake(self.bounds.size.width, 300));
//            make.bottom.mas_equalTo(self.likeNumLb.mas_top).mas_equalTo(-15);
            make.top.mas_equalTo(self.contentLb.mas_bottom).mas_equalTo(15);
        }];
        
        //笑脸
        [self.likeNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentIV.mas_bottom).mas_equalTo(15);
            make.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(60, 25));
//            make.bottom.mas_equalTo(-10);
        }];
        
        //评论
        [self.clicksNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(60, 25));
            make.centerY.mas_equalTo(self.likeNumLb);
            make.left.mas_equalTo(self.likeNumLb.mas_rightMargin).mas_equalTo(20);
        }];
        
        //        //分享
        //        [self.shareNumLb mas_makeConstraints:^(MASConstraintMaker *make) {
        //            make.centerY.mas_equalTo(self.clicksNumLb);
        //            make.size.mas_equalTo(CGSizeMake(60, 25));
        //            make.left.mas_equalTo(self.clicksNumLb.mas_rightMargin).mas_equalTo(20);
        //            
        //        }];
        
        [self.smileBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.top.mas_equalTo(self.likeNumLb.mas_bottom).mas_equalTo(25);
            make.left.mas_equalTo(30);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.cryBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.left.mas_equalTo(self.smileBtn.mas_right).mas_equalTo(40);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.messageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.left.mas_equalTo(self.cryBtn.mas_right).mas_equalTo(40);
            make.bottom.mas_equalTo(-10);
        }];
        
        [self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(33, 25));
            make.centerY.mas_equalTo(self.smileBtn);
            make.right.mas_equalTo(self.contentLb.mas_right);
            make.bottom.mas_equalTo(-10);

        }];
        

        
    }
    
    return self;
}


@end
