//
//  CommentsCell.h
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LKImageView.h"

@interface CommentsCell : UITableViewCell
//* 头像图片 */
@property(nonatomic,strong)LKImageView *iconIV;

/** 昵称标签 */
@property (nonatomic, strong) UILabel *nameLb;


/** 楼层数标签 */
@property (nonatomic, strong) UILabel *floorLb;


//* 评论正文标签 */
@property(nonatomic,strong)UILabel *contentLb;


@end
