//
//  CommentsCell.m
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "CommentsCell.h"

@implementation CommentsCell

- (LKImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[LKImageView alloc] init];
        _iconIV.imageView.image = [UIImage imageNamed:@"touxiang"];
        _iconIV.layer.cornerRadius=25;
        
    }
    return _iconIV;
}

- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.font = [UIFont systemFontOfSize:13];
        
    }
    return _nameLb;
}

- (UILabel *)floorLb {
    if(_floorLb == nil) {
        _floorLb = [[UILabel alloc] init];
        _floorLb.font = [UIFont systemFontOfSize:13];
    }
    return _floorLb;
}

- (UILabel *)contentLb {
    if(_contentLb == nil) {
        _contentLb = [[UILabel alloc] init];
        _contentLb.font = [UIFont systemFontOfSize:13];
    }
    return _contentLb;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self.contentView addSubview:self.iconIV];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.floorLb];
        [self.contentView addSubview:self.contentLb];

        
        //头像
        [self.iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(40, 40));
        }];
        //昵称
        [self.nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            //            make.top.mas_equalTo(15);
            make.centerY.mas_equalTo(self.iconIV.mas_centerY);
            make.left.mas_equalTo(self.iconIV.mas_right).mas_equalTo(10);
            make.width.mas_equalTo(100);
        }];
        //楼层
        [self.floorLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.size.mas_equalTo(CGSizeMake(45, 20));
            make.right.mas_equalTo(-10);
            make.top.mas_equalTo(20);
        }];
        
        //内容
        [self.contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_greaterThanOrEqualTo(20);
            make.left.mas_equalTo(self.nameLb.mas_left);
            make.top.mas_equalTo(self.iconIV.mas_bottomMargin).mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
    }

    return self;

}

@end
