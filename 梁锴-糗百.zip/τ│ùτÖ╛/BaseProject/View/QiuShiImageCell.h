//
//  QiuShiImageCell.h
//  BaseProject
//
//  Created by apple on 15/11/16.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LKImageView.h"

@interface QiuShiImageCell : UITableViewCell

//* 头像图片 */
@property(nonatomic,strong)LKImageView *iconIV;

//* 内容图片 */
@property(nonatomic,strong)LKImageView *contentIV;

//* 热门/新鲜图片 */
@property(nonatomic,strong)LKImageView *HotIV;

/** 昵称标签 */
@property (nonatomic, strong) UILabel *nameLb;

//* 正文标签 */
@property(nonatomic,strong)UILabel *contentLb;

//* 点赞标签 */
@property(nonatomic,strong)UILabel *likeNumLb;

//* 评论数标签 */
@property(nonatomic,strong)UILabel *clicksNumLb;

//* 分享数标签 */
@property(nonatomic,strong)UILabel *shareNumLb;


/** 笑脸 */
@property (nonatomic, strong) UIButton *smileBtn;
/** 伤心 */
@property (nonatomic, strong) UIButton *cryBtn;
/** 消息 */
@property (nonatomic, strong) UIButton *messageBtn;
/** 分享 */
@property (nonatomic, strong) UIButton *shareBtn;

@end
