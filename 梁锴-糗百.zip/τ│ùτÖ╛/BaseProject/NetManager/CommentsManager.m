//
//  CommentsManager.m
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "CommentsManager.h"

@implementation CommentsManager

+ (id)getCommentsID:(NSInteger)ID andCommentsPage:(NSInteger)page completionHandle:(void (^)(CommentsModel *, NSError *))completionHandle
{
    NSString *path=[NSString stringWithFormat:@"http://m2.qiushibaike.com/article/%@/comments?article=1&count=50&page=%@&AdID=144816154420847E713351", @(ID),@(page)];
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([CommentsModel objectWithKeyValues:responseObj], error);
        
    }];
}

@end
