//
//  CommentsManager.h
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseNetManager.h"
#import "CommentsModel.h"
@interface CommentsManager : BaseNetManager

//http://m2.qiushibaike.com/article/113915323/comments?article=1&count=50&page=1&AdID=144816154420847E713351


+ (id)getCommentsID:(NSInteger)ID andCommentsPage:(NSInteger)page completionHandle:(void(^)(CommentsModel *model, NSError *error))completionHandle;

@end
