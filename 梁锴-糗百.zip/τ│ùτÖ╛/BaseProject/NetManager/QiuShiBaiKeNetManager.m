//
//  QiuShiBaiKeNetManager.m
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiBaiKeNetManager.h"

/*
 糗事百科
 
 专享  http://m2.qiushibaike.com/article/list/suggest?count=30&page=1&AdID=144741115984117E713351
 视频  http://m2.qiushibaike.com/article/list/video?count=30&page=1&AdID=144741133282177E713351
 纯文  http://m2.qiushibaike.com/article/list/text?count=30&page=1&AdID=144741136448137E713351
 纯图  http://m2.qiushibaike.com/article/list/imgrank?count=30&page=1&AdID=144741143934917E713351
 精华  http://m2.qiushibaike.com/article/list/day?count=30&page=1&AdID=144741147954877E713351
 最新  http://m2.qiushibaike.com/article/list/latest?count=30&page=1&AdID=144741152378707E713351
 */

@implementation QiuShiBaiKeNetManager

+ (id)getQiuShiBaiKeListType:(QiuShiBaiKeListType)type  page:(NSInteger)page completionHandle:(void (^)(QiushiBaiKeModel *, NSError *))completionHandle
{
    //需要根据不同的类型,设置对应的请求地址
    NSString *path = nil;
    //修改链接地址为p%@ l%@ ,对应 @(page)
    switch (type) {
        case QiuShiBaiKeListTypeZhuanXiang:    //专享
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/suggest?count=30&page=%@&AdID=144741115984117E713351",@(page)];
            break;
        case QiuShiBaiKeListTypeShiPin:  //视频
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/video?count=30&page=%@&AdID=144741133282177E713351",@(page)];
            break;
        case QiuShiBaiKeListTypeChunWen:  //纯文
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/text?count=30&page=%@&AdID=144741136448137E713351",@(page)];
            
            break;
        case QiuShiBaiKeListTypeChunTu:   //纯图
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/imgrank?count=30&page=%@&AdID=144741143934917E713351",@(page)];
            break;
            
        case QiuShiBaiKeListTypeJingHua:   //精华
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/day?count=30&page=%@&AdID=144741147954877E713351",@(page)];
            break;
        case QiuShiBaiKeListTypeZuiXin:   //最新
            path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/latest?count=30&page=%@&AdID=144741152378707E713351",@(page)];
            
            break;
            
        default:
            
            break;
    }
    
    //请求下来的数据公用一个解析类,就可以合写
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([QiushiBaiKeModel objectWithKeyValues:responseObj],error);
    }];
    
    
}

@end
