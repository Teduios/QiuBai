//
//  FriendNetManager.h
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseNetManager.h"
#import "FriendModel.h"
//http://circle.qiushibaike.com/article/nearby/list?latitude=0&longitude=0&page=1&AdID=144741694944597E713351

@interface FriendNetManager : BaseNetManager

+ (id)getFriendpage:(NSInteger)page completionHandle:(void(^)(FriendModel *model, NSError *error))completionHandle;

@end
