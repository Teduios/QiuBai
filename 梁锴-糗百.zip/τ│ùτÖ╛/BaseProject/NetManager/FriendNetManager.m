//
//  FriendNetManager.m
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FriendNetManager.h"

@implementation FriendNetManager


+ (id)getFriendpage:(NSInteger)page completionHandle:(void (^)(FriendModel *, NSError *))completionHandle
{
    NSString *path=[NSString stringWithFormat:@"http://circle.qiushibaike.com/article/nearby/list?latitude=0&longitude=0&page=%@&AdID=144741694944597E713351", @(page)];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        completionHandle([FriendModel objectWithKeyValues:responseObj], error);
        
    }];
}


@end
