//
//  QiuShiBaiKeNetManager.h
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseNetManager.h"
#import "QiushiBaiKeModel.h"

typedef NS_ENUM(NSUInteger, QiuShiBaiKeListType) {
    QiuShiBaiKeListTypeZhuanXiang,  //专享
    QiuShiBaiKeListTypeShiPin,  //视频
    QiuShiBaiKeListTypeChunWen,   //纯文
    QiuShiBaiKeListTypeChunTu,   //纯图
    QiuShiBaiKeListTypeJingHua,  //精华
    QiuShiBaiKeListTypeZuiXin,  //最新
    
};


/*
 糗事百科
 
 专享  http://m2.qiushibaike.com/article/list/suggest?count=30&page=1&AdID=144741115984117E713351
 视频  http://m2.qiushibaike.com/article/list/video?count=30&page=1&AdID=144741133282177E713351
 纯文  http://m2.qiushibaike.com/article/list/text?count=30&page=1&AdID=144741136448137E713351
 纯图  http://m2.qiushibaike.com/article/list/imgrank?count=30&page=1&AdID=144741143934917E713351
 精华  http://m2.qiushibaike.com/article/list/day?count=30&page=1&AdID=144741147954877E713351
 最新  http://m2.qiushibaike.com/article/list/latest?count=30&page=1&AdID=144741152378707E713351
 */

@interface QiuShiBaiKeNetManager : BaseNetManager
//通过type来区分请求地址'

+ (id)getQiuShiBaiKeListType:(QiuShiBaiKeListType)type  page:(NSInteger)page completionHandle:(void(^)(QiushiBaiKeModel *model, NSError *error))completionHandle;

@end
