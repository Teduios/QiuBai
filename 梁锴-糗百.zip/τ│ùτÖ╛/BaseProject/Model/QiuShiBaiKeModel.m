//
//  QiushiBaiKeModel.m
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiushiBaiKeModel.h"

@implementation QiushiBaiKeModel


+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"acount":@"count"};
}

+ (NSDictionary *)objectClassInArray{
    return @{@"items" : [QiushiBaiItemsKeModel class]};
}


//+ (NSDictionary *)objectClassInArray{
//    return @{@"items" : [Items class]};
//}

@end




@implementation QiushiBaiItemsKeModel
+ (NSDictionary *)objectClassInArray{
    return @{@"pic_size" : [QiushiBaiItemsKeModel class],@"pic_size":[QiushiBaiItemsImage_SizeModel class]};
}


+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}



@end



@implementation QiushiBaiItemsKeVotesModel

@end




@implementation QiushiBaiItemsKeUserModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end


@implementation QiushiBaiItemsImage_SizeModel



@end

