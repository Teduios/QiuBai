//
//  BaseModel.h
//  BaseProject
//
//  Created by apple on 15/10/21.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
