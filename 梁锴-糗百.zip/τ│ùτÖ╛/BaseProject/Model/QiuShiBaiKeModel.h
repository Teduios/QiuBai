//
//  QiushiBaiKeModel.h
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

/*
 糗事百科
 
 专享  http://m2.qiushibaike.com/article/list/suggest?count=30&page=1&AdID=144741115984117E713351
 视频  http://m2.qiushibaike.com/article/list/video?count=30&page=1&AdID=144741133282177E713351
 纯文  http://m2.qiushibaike.com/article/list/text?count=30&page=1&AdID=144741136448137E713351
 纯图  http://m2.qiushibaike.com/article/list/imgrank?count=30&page=1&AdID=144741143934917E713351
 精华  http://m2.qiushibaike.com/article/list/day?count=30&page=1&AdID=144741147954877E713351
 最新  http://m2.qiushibaike.com/article/list/latest?count=30&page=1&AdID=144741152378707E713351
 */

#import "BaseModel.h"

@class QiushiBaiItemsKeModel,QiushiBaiItemsKeVotesModel,QiushiBaiItemsKeUserModel,QiushiBaiItemsImage_SizeModel;


@interface QiushiBaiKeModel : BaseModel

@property (nonatomic, assign) NSInteger err;

@property (nonatomic, assign) NSInteger refresh;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) NSArray<QiushiBaiItemsKeModel *> *items;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger page;

@end





@interface QiushiBaiItemsKeModel : NSObject

@property (nonatomic, assign) NSInteger published_at;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *state;

@property (nonatomic, copy) NSString *low_url;

@property (nonatomic, strong) NSArray<NSNumber *> *pic_size;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, assign) NSInteger share_count;

@property (nonatomic, assign) NSInteger loop;

@property (nonatomic, copy) NSString *pic_url;

@property (nonatomic, copy) NSString *tag;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *imgsize;

@property (nonatomic, strong) QiushiBaiItemsImage_SizeModel *image_size;

@property (nonatomic, copy) NSString *format;

@property (nonatomic, assign) BOOL allow_comment;

@property (nonatomic, assign) NSInteger comments_count;

@property (nonatomic, strong) QiushiBaiItemsKeUserModel *user;

@property (nonatomic, copy) NSString *high_url;

@property (nonatomic, strong) QiushiBaiItemsKeVotesModel *votes;

@end





@interface QiushiBaiItemsKeVotesModel : NSObject

@property (nonatomic, assign) NSInteger up;

@property (nonatomic, assign) NSInteger down;

@end





@interface QiushiBaiItemsKeUserModel : NSObject

@property (nonatomic, copy) NSString *login;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, assign) NSInteger avatar_updated_at;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, copy) NSString *role;

@property (nonatomic, assign) NSInteger id;

@property (nonatomic, copy) NSString *email;

@property (nonatomic, copy) NSString *last_device;

@property (nonatomic, copy) NSString *state;

@property (nonatomic, assign) NSInteger last_visited_at;

@end



@interface QiushiBaiItemsImage_SizeModel : NSObject

@property (nonatomic, strong) NSArray<NSNumber *> *s;

@property (nonatomic, strong) NSArray<NSNumber *> *m;

@end

