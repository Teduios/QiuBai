//
//  CommentsModel.m
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "CommentsModel.h"

@implementation CommentsModel



+ (NSDictionary *)objectClassInArray{
    return @{@"items" : [ItemsModel class]};
}
@end



@implementation ArticleModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end


@implementation ArticleVotesModel

@end


@implementation ArticleUserModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end


@implementation ItemsModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end


@implementation ItemsUserModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end


