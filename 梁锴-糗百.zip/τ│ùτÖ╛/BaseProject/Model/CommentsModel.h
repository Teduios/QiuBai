//
//  CommentsModel.h
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseModel.h"

@class ArticleModel,ArticleVotesModel,ArticleUserModel,ItemsModel,ItemsUserModel;
@interface CommentsModel : BaseModel

@property (nonatomic, assign) NSInteger err;

@property (nonatomic, strong) ArticleModel *article;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, strong) NSArray<ItemsModel *> *items;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger page;

@end
@interface ArticleModel : NSObject

@property (nonatomic, assign) NSInteger published_at;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *state;

@property (nonatomic, assign) NSInteger anonymous;

@property (nonatomic, assign) BOOL is_mine;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, assign) NSInteger user_id;

@property (nonatomic, strong) NSArray *comment;

@property (nonatomic, copy) NSString *tag;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *image_size;

@property (nonatomic, copy) NSString *format;

@property (nonatomic, assign) BOOL allow_comment;

@property (nonatomic, assign) NSInteger comments_count;

@property (nonatomic, strong) ArticleUserModel *user;

@property (nonatomic, assign) NSInteger share_count;

@property (nonatomic, strong) ArticleVotesModel *votes;

@end

@interface ArticleVotesModel : NSObject

@property (nonatomic, assign) NSInteger up;

@property (nonatomic, assign) NSInteger down;

@end

@interface ArticleUserModel : NSObject

@property (nonatomic, copy) NSString *login;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, copy) NSString *role;

@property (nonatomic, copy) NSString *email;

@property (nonatomic, copy) NSString *last_device;

@property (nonatomic, copy) NSString *state;

@property (nonatomic, assign) NSInteger last_visited_at;

@end

@interface ItemsModel : NSObject

@property (nonatomic, strong) ItemsUserModel *user;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, assign) NSInteger floor;

@end

@interface ItemsUserModel : NSObject

@property (nonatomic, copy) NSString *login;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, copy) NSString *role;

@property (nonatomic, copy) NSString *email;

@property (nonatomic, copy) NSString *last_device;

@property (nonatomic, copy) NSString *state;

@property (nonatomic, assign) NSInteger last_visited_at;

@end

