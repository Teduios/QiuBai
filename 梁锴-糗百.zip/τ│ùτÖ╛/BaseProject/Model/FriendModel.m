//
//  FriendModel.m
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FriendModel.h"

@implementation FriendModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [FriendDataModel class]};
}


@end




@implementation FriendDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"pic_urls" : [Pic_Urls class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}
@end


@implementation FriendDataVoteModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}
@end


@implementation FriendDataUserModel
+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}
@end


@implementation Pic_Urls

@end

@implementation FriendDataTopicModel

+ (NSDictionary *)replacedKeyFromPropertyName
{
    //特殊的命名的属性
    return @{@"ID":@"id"};
}

@end
