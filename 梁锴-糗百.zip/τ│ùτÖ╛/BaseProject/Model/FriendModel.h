//
//  FriendModel.h
//  BaseProject
//
//  Created by apple on 15/11/13.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseModel.h"

@class FriendDataModel,FriendDataVoteModel,FriendDataUserModel,FriendDataTopicModel, Pic_Urls;

@class Data,Vote,User;
@interface FriendModel : BaseModel



@property (nonatomic, assign) BOOL has_more;

@property (nonatomic, strong) NSArray<FriendDataModel *> *data;

@property (nonatomic, assign) NSInteger err;

@property (nonatomic, assign) NSInteger refresh;

@property (nonatomic, assign) NSInteger total;

@end



@interface FriendDataModel : NSObject

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *distance;

@property (nonatomic, assign) NSInteger like_count;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, strong) NSArray<Pic_Urls *> *pic_urls;

@property (nonatomic, copy) NSString *loaction;

@property (nonatomic, assign) NSInteger comment_count;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, strong) FriendDataVoteModel *vote;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, strong) FriendDataUserModel *user;

@property (nonatomic, strong) FriendDataTopicModel *topic;


@end

@interface FriendDataVoteModel : NSObject
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, assign) NSInteger oa_content;
@property (nonatomic, assign) NSInteger ob_content;
@property (nonatomic, assign) NSInteger option_a;
@property (nonatomic, assign) NSInteger option_b;
@end

@interface FriendDataUserModel : NSObject

@property (nonatomic, copy) NSString *gender;

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger created_at;

@property (nonatomic, assign) NSInteger age;

@property (nonatomic, assign) NSInteger nick_status;

@property (nonatomic, copy) NSString *icon;

@property (nonatomic, copy) NSString *login;

@end

@interface Pic_Urls : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *pic_url;

@end

@interface FriendDataTopicModel : NSObject
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, assign) NSInteger color;
@end

