//
//  LKAvatarBrowser.h
//  BaseProject
//
//  Created by apple on 15/11/24.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LKAvatarBrowser : NSObject
/**
 
 *
 @brief  浏览头像
 
 *
 
 *
 @param  oldImageView    头像所在的imageView
 
 */

+(void)showImage:(UIImageView*)avatarImageView;

@end
