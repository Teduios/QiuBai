//
//  Factory.h
//  BaseProject
//
//  Created by apple on 15/11/5.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <RESideMenu.h>

@interface Factory : NSObject
/** 向某个控制器上，添加菜单按钮 */
+ (void)addMenuItemToVC:(UIViewController *)vc;

/** 向某个控制器上，添加返回按钮 */
+ (void)addBackItemToVC:(UIViewController *)vc;

/** 向某个控制器上，添加加号按钮 */
//+ (void)addAddItemToVC:(UIViewController *)vc;




@end









