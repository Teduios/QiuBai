//
//  LoginTableViewController.m
//  BaseProject
//
//  Created by apple on 15/11/19.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "LoginTableViewController.h"
#import "UMSocial.h"
#import "MeTableViewController.h"

#import "LKWAccount.h"
#import "LKQAuthController.h"
@interface LoginTableViewController ()<MeTableViewControllerDelegate>
//将第三方登录后发送过来的ToKen保存到UserDefault
@property (nonatomic, strong) NSUserDefaults *userDefault;



@property (weak, nonatomic) IBOutlet UITextField *usernameLb;

@property (weak, nonatomic) IBOutlet UITextField *pwdLb;

@end

@implementation LoginTableViewController

+ (UINavigationController *)standardQiuShiNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        LoginTableViewController *vc = kVCFromSb(@"Login", @"Main");

        navi = [[UINavigationController alloc] initWithRootViewController:vc];
    });
    return navi;
}



- (NSUserDefaults *)userDefault{
    if (!_userDefault) {
        //单例模式
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}

- (IBAction)cancelBtn:(UIButton *)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
    NSLog(@"取消");
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    [Factory addBackItemToVC:self];
    
//    self.tableView.userInteractionEnabled = NO;
    
    UIImage *imageN = [UIImage imageNamed:@"icon"];
    UIImageView *leftViewN = [[UIImageView alloc]initWithImage:imageN];
    leftViewN.contentMode = UIViewContentModeCenter;
    leftViewN.frame = CGRectMake(0, 0, 45, 45);
    
    self.usernameLb.leftView = leftViewN;
    
    self.usernameLb.leftViewMode = UITextFieldViewModeAlways;
    
    UIImage *imagePWD = [UIImage imageNamed:@"lock"];
    UIImageView *leftViewPWD = [[UIImageView alloc]initWithImage:imagePWD];
    leftViewPWD.contentMode = UIViewContentModeCenter;
    leftViewPWD.frame = CGRectMake(0, 0, 45, 45);
    
    self.pwdLb.leftView = leftViewPWD;
    
    self.pwdLb.leftViewMode = UITextFieldViewModeAlways;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 1 && indexPath.row == 0) {
        NSLog(@"微信登录");
    }
    
    if (indexPath.section == 1 && indexPath.row == 1) {
        NSLog(@"QQ登录");
        
        UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
        
        snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
            
            //          获取微博用户名、uid、token等
            
            if (response.responseCode == UMSResponseCodeSuccess) {
                
                UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
                
                NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                
            }});

        
    }
    
    if (indexPath.section == 1 && indexPath.row == 2) {
        NSLog(@"微博登录");
//        //跳转到新的页面登录
//        LKQAuthController *vc = [LKQAuthController new];
//        
//        [self presentViewController:vc animated:YES completion:nil];
//        
//        
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"show" object:nil];
        
        UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];

        snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
            
            //          获取微博用户名、uid、token等
            
            if (response.responseCode == UMSResponseCodeSuccess) {
                
                UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
                
                NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                
          //将获取到数据，写入用户本地
                [self.userDefault setValue:snsAccount.userName forKey:@"userName"];
                [self.userDefault setValue:snsAccount.usid forKey:@"usid"];
                [self.userDefault setValue:snsAccount.accessToken forKey:@"accessToKen"];
                [self.userDefault setValue:snsAccount.iconURL forKey:@"iconURL"];
                
                
                [self.userDefault synchronize];
    

             [[NSNotificationCenter defaultCenter] postNotificationName:@"show" object:nil];
            
                
                
            }});
        
        
       
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.01;
    }
    return 30;
}

// 返回分组的标题文字
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return @"使用合作账号一键登录/注册";
    }
    if (section == 2) {
        return @"使用糗百账号登录";
    }
    return nil;
}




@end
