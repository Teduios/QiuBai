//
//  LoginTableViewController.h
//  BaseProject
//
//  Created by apple on 15/11/19.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginTableViewController : UITableViewController

+ (UINavigationController *)standardQiuShiNavi;
@end
