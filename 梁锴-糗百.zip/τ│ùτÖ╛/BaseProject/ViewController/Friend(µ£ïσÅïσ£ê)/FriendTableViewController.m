//
//  FriendTableViewController.m
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FriendTableViewController.h"
#import "FriendCell.h"
#import "FriendViewModel.h"
#import "LKAvatarBrowser.h"
@interface FriendTableViewController ()

@property (nonatomic, strong)FriendViewModel *friendVM;
//@property (nonatomic, strong)UIImageView *imgView;
@end

@implementation FriendTableViewController

- (FriendViewModel *)friendVM {
    if(_friendVM == nil) {
        _friendVM = [[FriendViewModel alloc] init];
    }
    return _friendVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"----糗友圈");
    [self.tableView registerClass:[FriendCell class] forCellReuseIdentifier:@"FriendListCell"];
    
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.friendVM refreshDataCompleteHandle:^(NSError *error) {
            
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
        }];
    }];
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.friendVM getMoreCompleteHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    [self.tableView.header beginRefreshing];
    
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.friendVM.rowNumber;
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

        FriendCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"FriendListCell" forIndexPath:indexPath];
    
        //头像
        [Cell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
        //正文
        Cell.contentLb.text = [self.friendVM contentLbForRow:indexPath.row];
        //昵称
        Cell.nameLb.text = [self.friendVM nameLbForRow:indexPath.row];
    
    
    
    if (![self.friendVM isHasImageForRow:indexPath.row]) {
        [Cell.contentIV.imageView setImageWithURL:[self.friendVM contentIVForRow:indexPath.row]];
//        self.imgView = Cell.contentIV.imageView;
//        
//        UITapGestureRecognizer *tap  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(magnifyImageIV)];
//        
//        [Cell.contentIV addGestureRecognizer:tap];

    }
    
        //分享
        Cell.locationLb.text = [self.friendVM locationForRow:indexPath.row];

        //好笑
        Cell.likeNumLb.text = [self.friendVM likeCountForRow:indexPath.row];
    
        //评论
        Cell.clicksNumLb.text = [self.friendVM commentCountForRow:indexPath.row];
    
       
    
        Cell.is = [self.friendVM isGender:indexPath.row];
    
        NSLog(@"%@",[self.friendVM isGender:indexPath.row]?@"YES":@"NO");
    

    
        return Cell;

}

//- (void)magnifyImageIV
//{
//    NSLog(@"局部放大");
//    [LKAvatarBrowser showImage:self.imgView];//调用方法
//}

/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat maxW = self.tableView.frame.size.width - 2 * 10;
    
    CGSize contentSize = [[self.friendVM contentLbForRow:indexPath.row] sizeWithFont:LKWStatusCellContentFont maxW:maxW];
    
    NSLog(@"高度%lf",contentSize.height);

    if ([self.friendVM isHasImageForRow:indexPath.row]) {
        return contentSize.height + 250;
    }
    return contentSize.height + 250;
    
}




@end
