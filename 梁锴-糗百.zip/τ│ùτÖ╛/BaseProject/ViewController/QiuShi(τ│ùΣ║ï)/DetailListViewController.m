//
//  DetailListViewController.m
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "DetailListViewController.h"
#import "detailQiuShiViewModel.h"
#import "CommentsModel.h"
#import "CommentsCell.h"
#import "QiuShiListCell.h"
#import "QiuShiImageCell.h"
#import "QiuShiVideoCell.h"
#import "QiuShiViewModel.h"

@interface DetailListViewController ()<UITableViewDelegate>

@property (nonatomic, strong)detailQiuShiViewModel *detailVM;
@property (nonatomic, strong)QiuShiViewModel *qiushiVM;
@end

@implementation DetailListViewController

- (QiuShiViewModel *)qiushiVM {
    if(_qiushiVM == nil) {
        _qiushiVM = [[QiuShiViewModel alloc] initWithQiuShiListType:_infoType.integerValue];
    }
    return _qiushiVM;
}


- (detailQiuShiViewModel *)detailVM {
    if(_detailVM == nil) {
        _detailVM = [[detailQiuShiViewModel alloc] initWithID:self.ID];
    }
    return _detailVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[QiuShiListCell class] forCellReuseIdentifier:@"QiuShiListCell"];
    [self.tableView registerClass:[QiuShiImageCell class] forCellReuseIdentifier:@"QiuShiImageCell"];
    [self.tableView registerClass:[QiuShiVideoCell class] forCellReuseIdentifier:@"QiuShiVideoCell"];
    
    [self.tableView registerClass:[CommentsCell class] forCellReuseIdentifier:@"CommentsCell"];
    
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.detailVM refreshDataCompleteHandle:^(NSError *error) {
            
            NSLog(@"详情打印:%ld",self.ID);
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
        }];
        
        
//        [self.qiushiVM refreshDataCompleteHandle:^(NSError *error) {
//            
//            [self.tableView reloadData];
//            [self.tableView.header endRefreshing];
//
//        }];

        
        
    }];
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        
        [self.detailVM getMoreCompleteHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
        
//        [self.qiushiVM getMoreCompleteHandle:^(NSError *error) {
//            [self.tableView reloadData];
//            [self.tableView.footer endRefreshing];
//            
//        }];
        
    }];
    [self.tableView.header beginRefreshing];
    
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSLog(@"%ld",self.detailVM.rowNumber);
    
//    if (section == 0) {
//        return 1;
//    }
    
    return self.detailVM.rowNumber;
}

////两个分区
//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 2;
//}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
   
    
//
//   if (indexPath.section == 0) {
//       return nil;
//   }
//        NSLog(@"没有正文图片");
//        QiuShiListCell *listCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiListCell" forIndexPath:indexPath];
//        
//        //正文
//        listCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
//        //昵称
//        listCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
//        
//        //好笑
//        listCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];
//        
//        //评论
//        listCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];
//        
//        //分享
//        listCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];
//        
//        
//        //头像:没有找到规律获取头像
//        [listCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
//        
//        [listCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
//        
//        return listCell;
//
//    }else{

    CommentsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommentsCell"];
    
    cell.contentLb.text = [self.detailVM contentForRow:indexPath.row];
    
    cell.nameLb.text = [self.detailVM loginForRow:indexPath.row];
    
    cell.floorLb.text = [NSString stringWithFormat:@"%ld楼",[self.detailVM floorForRow:indexPath.row]];

    NSLog(@"评论%@",cell.contentLb.text);
    
    return cell;
//    }
}


/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat maxW = self.tableView.frame.size.width - 2 * 10;
    
    CGSize contentSize = [[self.detailVM contentForRow:indexPath.row] sizeWithFont:LKWStatusCellContentFont maxW:maxW];
    
    return contentSize.height + 100;
    
}


@end


//        if (![self.qiushiVM containImages:indexPath.row]) {
//            QiuShiImageCell *imageCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiImageCell" forIndexPath:indexPath];
//            NSLog(@"有正文图片");
//
//            //正文
//            imageCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
//            //昵称
//            imageCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
//
//            NSString *str = [NSString stringWithFormat:@"%@",[self.qiushiVM contentIVForRow:indexPath.row]];
//
//            [imageCell.contentIV.imageView setImageWithURL:[NSURL URLWithString:str]];
//
//            //好笑
//            imageCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];
//
//            //评论
//            imageCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];
//
//            //分享
//            imageCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];
//
//            //头像:没有找到规律获取头像
//            [imageCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
//
//            [imageCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
//            return imageCell;
//
//        }
//
//        if ([self.qiushiVM isVideoForRow:indexPath.row]){
//            QiuShiVideoCell *videoCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiVideoCell" forIndexPath:indexPath];
//            //正文
//            videoCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
//
//            //昵称
//            videoCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
//
//            //视频正文图片
//            [videoCell.contentIV.imageView setImageWithURL:[self.qiushiVM contentUrlForRow:indexPath.row]];
//
//            //好笑
//            videoCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];
//
//            //评论
//            videoCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];
//
//            //分享
//            videoCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];
//
//
//            //头像:没有找到规律获取头像
//            [videoCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
//
//            [videoCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
//
//            videoCell.videoURL =[self.qiushiVM videoURLForRow:indexPath.row];
//            NSLog(@"- -%@",videoCell.videoURL);
//
//            return videoCell;
//        }

