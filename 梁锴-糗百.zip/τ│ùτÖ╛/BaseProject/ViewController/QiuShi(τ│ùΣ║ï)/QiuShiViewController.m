//
//  QiuShiViewController.m
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiViewController.h"
#import "QiuShiViewModel.h"
#import "QiuShiListViewController.h"

@interface QiuShiViewController ()

@end

@implementation QiuShiViewController



+ (UINavigationController *)standardQiuShiNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        QiuShiViewController *vc = [[QiuShiViewController alloc] initWithViewControllerClasses:[self viewControllerClasses] andTheirTitles:[self itemNames]];
        
        //例如设置第一个控制器的某个属性的值, KVC
        //vc setValue:[values[0]] forKey:keys[0]
        vc.keys = [self vcKeys];
        vc.values = [self vcValues];
        
        navi = [[UINavigationController alloc] initWithRootViewController:vc];
    });
    return navi;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor greenSeaColor];
    UIImageView *imageView  = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo"]];
    imageView.size  = CGSizeMake(98, 40);
    self.navigationItem.titleView = imageView;
    self.title = @"糗事";
    
    [Factory addMenuItemToVC:self];
    
   
}
/** 提供题目数组 */
+ (NSArray *)itemNames{
    return @[@"专享",@"视频",@"纯文",@"纯图",@"精华",@"最新"];
}

/** 提供每个VC对应的values值数组 */
+ (NSArray *)vcValues{
    NSMutableArray *arr = [NSMutableArray new];
    for (int i = 0; i <[self itemNames].count; i++) {
        //数值上，vc的infoType的枚举值 恰好和i值相同
        [arr addObject:@(i)];
    }
    return arr;
}
/** 提供每个VC对应的key值数组 */
+ (NSArray *)vcKeys{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:@"infoType"];
    }
    return [arr copy];
}

/** 提供每个题目对应的控制器的类型。题目和类型数量必须一致 */
+ (NSArray *)viewControllerClasses{
    NSMutableArray *arr = [NSMutableArray new];
    for (id obj in [self itemNames]) {
        [arr addObject:[QiuShiListViewController class]];
    }
    return [arr copy];
}



@end
