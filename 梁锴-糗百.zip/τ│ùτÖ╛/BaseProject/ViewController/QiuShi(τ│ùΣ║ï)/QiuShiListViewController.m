//
//  QiuShiListViewController.m
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiListViewController.h"
#import "QiuShiListCell.h"
#import "QiuShiImageCell.h"
#import "QiuShiViewModel.h"
#import "QiuShiVideoCell.h"
#import "iCarousel.h"
#import "DetailListViewController.h"
#import "UMSocial.h"

#import "UMSocialSnsService.h"

@interface QiuShiListViewController ()<UITableViewDelegate, UMSocialUIDelegate>
@property (nonatomic, strong)QiuShiViewModel *qiushiVM;

@property (nonatomic, strong)UIImageView *imagView;
@end

@implementation QiuShiListViewController


- (QiuShiViewModel *)qiushiVM {
    if(_qiushiVM == nil) {
        _qiushiVM = [[QiuShiViewModel alloc] initWithQiuShiListType:_infoType.integerValue];
    }
    return _qiushiVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    
    /**
     设置响应摇一摇事件，并且弹出分享页面
     
     @param snsTypes 要分享的平台类型名，例如@[UMShareToSina,UMShareToTencent,UMShareToWechatSession]
     @param shareText 分享内嵌文字
     @param screenShoter 摇一摇分享用到的截屏对象
     @param controller  出现分享界面所在的ViewController
     @param delegate 实现摇一摇后，或者分享完成后的回调对象，如果不处理这些事件，可以设置为nil
     */
    [UMSocialShakeService setShakeToShareWithTypes:@[UMShareToSina,UMShareToWechatSession]
                                         shareText:@"精彩瞬间,摇摇分享~"
                                      screenShoter:[UMSocialScreenShoterDefault screenShoter]
                                  inViewController:self
                                          delegate:nil];
    
    
    
    //设置摇一摇灵敏度
    [UMSocialShakeService setShakeThreshold:1.0];
    
    
    
    [self.tableView registerClass:[QiuShiListCell class] forCellReuseIdentifier:@"QiuShiListCell"];
    [self.tableView registerClass:[QiuShiImageCell class] forCellReuseIdentifier:@"QiuShiImageCell"];
    [self.tableView registerClass:[QiuShiVideoCell class] forCellReuseIdentifier:@"QiuShiVideoCell"];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.qiushiVM refreshDataCompleteHandle:^(NSError *error) {
            
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
        }];
    }];
    
    
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.qiushiVM getMoreCompleteHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
    
}


#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return  self.qiushiVM.rowNumber;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    if (![self.qiushiVM containImages:indexPath.row]) {
        QiuShiImageCell *imageCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiImageCell" forIndexPath:indexPath];
        NSLog(@"有正文图片");

        //正文
        imageCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
        //昵称
        imageCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
        
        NSString *str = [NSString stringWithFormat:@"%@",[self.qiushiVM contentIVForRow:indexPath.row]];

        [imageCell.contentIV.imageView setImageWithURL:[NSURL URLWithString:str]];
        self.imagView = imageCell.contentIV.imageView;
        
        UITapGestureRecognizer *tap  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(magnifyImage)];
        
        [imageCell.contentIV addGestureRecognizer:tap];
        
        
        //好笑
        imageCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];

        //评论
        imageCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];

        //分享
        imageCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];

        //头像:没有找到规律获取头像
        [imageCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
        
        [imageCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
        [imageCell.shareBtn bk_removeEventHandlersForControlEvents:UIControlEventTouchUpInside];
        
        [imageCell.shareBtn bk_addEventHandler:^(id sender) {
            
            NSLog(@"分享按钮点击了");
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"564da27d67e58e296b00021a"
                                              shareText:@"精彩瞬间,马上分享"
                                             shareImage:[UIImage imageNamed:@"icon"]
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToEmail,
                                                         UMShareToSms,UMShareToWechatSession,UMShareToWechatTimeline,UMShareToWechatFavorite,nil]
                                               delegate:self];
            [UMSocialData defaultData].extConfig.wechatSessionData.url = @"http://www.qiushibaike.com";
            [UMSocialData defaultData].extConfig.wechatTimelineData.url = @"http://www.qiushibaike.com";
        } forControlEvents:UIControlEventTouchUpInside];
        
        return imageCell;

    }
    if ([self.qiushiVM isVideoForRow:indexPath.row]){
        QiuShiVideoCell *videoCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiVideoCell" forIndexPath:indexPath];
        //正文
        videoCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
        
        //昵称
        videoCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
        
        //视频正文图片
        [videoCell.contentIV.imageView setImageWithURL:[self.qiushiVM contentUrlForRow:indexPath.row]];
    
        //好笑
        videoCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];
        
        //评论
        videoCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];
        
        //分享
        videoCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];
        
        
        //头像:没有找到规律获取头像
        [videoCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
        
        [videoCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
        
        videoCell.videoURL =[self.qiushiVM videoURLForRow:indexPath.row];
        NSLog(@"- -%@",videoCell.videoURL);
        
        
        [videoCell.shareBtn bk_removeEventHandlersForControlEvents:UIControlEventTouchUpInside];
        
        [videoCell.shareBtn bk_addEventHandler:^(id sender) {
            
            NSLog(@"分享按钮点击了");
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"564da27d67e58e296b00021a"
                                              shareText:@"精彩瞬间,马上分享,http://www.qiushibaike.com"
                                             shareImage:[UIImage imageNamed:@"icon"]
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToEmail,
                                                         UMShareToSms,UMShareToWechatSession,UMShareToWechatTimeline,UMShareToWechatFavorite,nil]
                                               delegate:self];
            [UMSocialData defaultData].extConfig.wechatSessionData.url = @"http://www.qiushibaike.com";
            [UMSocialData defaultData].extConfig.wechatTimelineData.url = @"http://www.qiushibaike.com";
        } forControlEvents:UIControlEventTouchUpInside];
        
        return videoCell;
    }


        NSLog(@"没有正文图片");
        QiuShiListCell *listCell = [tableView dequeueReusableCellWithIdentifier:@"QiuShiListCell" forIndexPath:indexPath];

        //正文
        listCell.contentLb.text = [self.qiushiVM contentForRow:indexPath.row];
        //昵称
        listCell.nameLb.text = [self.qiushiVM nameForRow:indexPath.row];
        
        //好笑
        listCell.likeNumLb.text = [self.qiushiVM smileNumberForRow:indexPath.row];
        
        //评论
        listCell.clicksNumLb.text = [self.qiushiVM commentsNumberForRow:indexPath.row];
        
        //分享
        listCell.shareNumLb.text = [self.qiushiVM shareNumberForRow:indexPath.row];
        
        
        //头像:没有找到规律获取头像
        [listCell.HotIV.imageView setImage:[UIImage imageNamed:@"UMS_wechat_favorite_icon"]];
        
        [listCell.iconIV.imageView setImage:[UIImage imageNamed:@"touxiang"]];
    
    [listCell.shareBtn bk_removeEventHandlersForControlEvents:UIControlEventTouchUpInside];
    
    [listCell.shareBtn bk_addEventHandler:^(id sender) {
        
        NSLog(@"分享按钮点击了");
        
        //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
        //如果需要分享回调，请将delegate对象设置self，并实现下面的回调方法
        [UMSocialSnsService presentSnsIconSheetView:self
                                             appKey:@"564da27d67e58e296b00021a"
                                          shareText:@"精彩瞬间,马上分享,http://www.qiushibaike.com"
                                         shareImage:[UIImage imageNamed:@"icon"]
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToRenren,UMShareToEmail,
                                                     UMShareToSms,UMShareToWechatSession,UMShareToWechatTimeline,UMShareToWechatFavorite,nil]
                                           delegate:self];
        [UMSocialData defaultData].extConfig.wechatSessionData.url = @"http://www.qiushibaike.com";
        [UMSocialData defaultData].extConfig.wechatTimelineData.url = @"http://www.qiushibaike.com";

        
    } forControlEvents:UIControlEventTouchUpInside];
    

        return listCell;
    
    
}

- (void)magnifyImage
{
    NSLog(@"局部放大");
    [LKAvatarBrowser showImage:self.imagView];//调用方法
}

/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    
    DetailListViewController *vc = [DetailListViewController new];
    
 
    vc.hidesBottomBarWhenPushed = YES;
    
    vc.ID = [self.qiushiVM getIDForRow:indexPath.row];
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
}

/** 滚动栏中被选中后触发 */
- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    /* 自动显示和隐藏tabbar */
    self.hidesBottomBarWhenPushed = YES;
    
    CGFloat maxW = self.tableView.frame.size.width - 2 * 10;
    
    CGSize contentSize = [[self.qiushiVM contentForRow:indexPath.row] sizeWithFont:LKWStatusCellContentFont maxW:maxW];
    
    
    
    if (![self.qiushiVM containImages:indexPath.row]){
        
//        NSNumber *number = [self.qiushiVM heightForRow:indexPath.row];
//        
//        double height = [number doubleValue];
//        

        return contentSize.height+ 65+ 400;
    }
    
    
    if ([self.qiushiVM isVideoForRow:indexPath.row]) {
        
        return contentSize.height+ 450;
    }
    
    return contentSize.height + 100;

}





@end
