//
//  QiuShiViewController.h
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WMPageController.h"

@interface QiuShiViewController : WMPageController

//内容页的首页应该是单例的，每次进程都只初始化一次

+ (UINavigationController *)standardQiuShiNavi;

@end
