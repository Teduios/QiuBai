//
//  MeTableViewController.h
//  BaseProject
//
//  Created by apple on 15/11/18.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>


@class MeTableViewController;


@protocol MeTableViewControllerDelegate <NSObject>
@optional
- (void)login:(MeTableViewController *)login;
@end



@interface MeTableViewController : UITableViewController

@property (nonatomic, weak) id<MeTableViewControllerDelegate> delegate;


@end
