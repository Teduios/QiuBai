//
//  MeTableViewController.m
//  BaseProject
//
//  Created by apple on 15/11/18.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "MeTableViewController.h"
#import "LoginTableViewController.h"
#import "UMSocial.h"

@interface MeTableViewController ()
@property (weak, nonatomic) IBOutlet UILabel *userNameLb;
@property (weak, nonatomic) IBOutlet UIImageView *userIconIV;
@property (nonatomic, strong)NSUserDefaults *userDefault;
@property (weak, nonatomic) IBOutlet UILabel *tipsLb;
@property (weak, nonatomic) IBOutlet UISwitch *switchBtn;

@end

@implementation MeTableViewController

//懒加载
- (NSUserDefaults *)userDefault
{
    if (!_userDefault) {
        //单例模式
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return  _userDefault;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    //去掉分割线
    
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    if ([self.userDefault stringForKey:@"userName"].length != 0) {
        [self refreshUserInfo];
    }

    
//    接收方

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshUserInfo) name:@"show" object:nil];
    
}



- (void)refreshUserInfo
{
    // 沙盒路径
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *path = [doc stringByAppendingPathComponent:@"account.archive"];
    
    NSLog(@"path --------- %@", path);
    
    self.userNameLb.text = [self.userDefault stringForKey:@"userName"];
    [self.userIconIV setImageWithURL:[NSURL URLWithString:[self.userDefault stringForKey:@"iconURL"]]];
    
    self.tipsLb.text = @"总访客  0     今日  0";
    self.userIconIV.layer.cornerRadius = 30;
    self.userIconIV.layer.masksToBounds = YES;


}
/** 去掉分割线左侧缝隙 */
kRemoveCellSeparator

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0 && indexPath.row == 1) {
        
        
        
        if ([self.userDefault stringForKey:@"userName"].length != 0) {
            
            return;
        }
        
        
//        [self.sideMenuViewController setContentViewController:[LoginTableViewController standardQiuShiNavi] animated:YES];
        
//        [self.sideMenuViewController hideMenuViewController];
        
        LoginTableViewController *vc = kVCFromSb(@"Login", @"Main");
        [self presentViewController:vc animated:YES completion:nil];

    }


}

- (IBAction)nightS:(id)sender {
    
    NSLog(@"夜间模式");
    if (self.switchBtn.on) {
//        self.view.backgroundColor = [UIColor darkGrayColor];
        NSLog(@"开启");
    }else{
//        self.view.backgroundColor = [UIColor whiteColor];
        NSLog(@"关闭");
    }
    
    
}


@end
