//
//  QiuShiBaiKeTabBarController.h
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface QiuShiBaiKeTabBarController : UITabBarController

+ (QiuShiBaiKeTabBarController *)standardInstance;

@end
