//
//  shopViewController.m
//  BaseProject
//
//  Created by apple on 15/11/21.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "shopViewController.h"

@interface shopViewController ()<UIWebViewDelegate>

@end

@implementation shopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"糗百货";
    [Factory addBackItemToVC:self];
    // 1.创建一个webView
    UIWebView *webView = [[UIWebView alloc] init];
    webView.frame = self.view.bounds;
    webView.delegate = self;
    [self.view addSubview:webView];
    
//http://www.qiushibaike.com/topic
    NSURL *url = [NSURL URLWithString:@"http://www.wemart.cn/v2/weimao/index.html?wemartIOSApp=true&user_id=ios_58D0A22B1F24F33280DB3134EC183F18&shopId=shop001201501095297"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webView loadRequest:request];

}

#pragma mark - webView代理方法
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self showProgress];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self showProgress];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self showProgress];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{

    return YES;
}



@end
