//
//  topicViewController.m
//  BaseProject
//
//  Created by apple on 15/11/21.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "topicViewController.h"

@interface topicViewController ()<UIWebViewDelegate>

@end

@implementation topicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"小鸡炖蘑菇";
    [Factory addBackItemToVC:self];
    // 1.创建一个webView
    UIWebView *webView = [[UIWebView alloc] init];
    webView.frame = self.view.bounds;
    webView.delegate = self;
    [self.view addSubview:webView];
    
    //http://www.qiushibaike.com/topic
    NSURL *url = [NSURL URLWithString:@"http://www.qiushibaike.com/topic"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [webView loadRequest:request];
    
}

#pragma mark - webView代理方法
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self showProgress];
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self showProgress];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self showProgress];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    return YES;
}

@end
