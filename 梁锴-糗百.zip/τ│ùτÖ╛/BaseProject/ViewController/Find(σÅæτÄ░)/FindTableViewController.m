//
//  FindTableViewController.m
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FindTableViewController.h"
#import "LoginTableViewController.h"
#import "shopViewController.h"
#import "topicViewController.h"

@interface FindTableViewController ()


@property (nonatomic, strong)NSUserDefaults *userDefault;
@end

@implementation FindTableViewController

//懒加载
- (NSUserDefaults *)userDefault
{
    if (!_userDefault) {
        //单例模式
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return  _userDefault;
}

- (void)viewDidLoad {
    [super viewDidLoad];


}

/** 附近 */
- (IBAction)nearbyBtn:(UIButton *)sender
{
    NSLog(@"点击了附近");
    if ([self.userDefault stringForKey:@"userName"].length == 0) {
        LoginTableViewController *vc = kVCFromSb(@"Login", @"Main");
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

/** 任意门*/
- (IBAction)doorBtn:(id)sender
{
    NSLog(@"点击了任意门");
    if ([self.userDefault stringForKey:@"userName"].length == 0) {
        LoginTableViewController *vc = kVCFromSb(@"Login", @"Main");
        [self.navigationController pushViewController:vc animated:YES];
    }
}

/** 群 */
- (IBAction)crowdBtn:(id)sender
{
    NSLog(@"点击了群");
    if ([self.userDefault stringForKey:@"userName"].length == 0) {
        LoginTableViewController *vc = kVCFromSb(@"Login", @"Main");
        [self.navigationController pushViewController:vc animated:YES];
    }
}

/** 糗百货 */
- (IBAction)shopBtn:(id)sender
{
    NSLog(@"点击了糗百货");
    //http://www.wemart.cn/v2/weimao/index.html?wemartIOSApp=true&user_id=ios_58D0A22B1F24F33280DB3134EC183F18&shopId=shop001201501095297
    shopViewController *vc = [shopViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Table view data source

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 1 && indexPath.row == 0) {
        shopViewController *vc = [shopViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    }
    if (indexPath.section == 2 && indexPath.row == 0) {
        topicViewController *vc = [topicViewController new];
        [self.navigationController pushViewController:vc animated:YES];

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{

    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    
    return 10;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
