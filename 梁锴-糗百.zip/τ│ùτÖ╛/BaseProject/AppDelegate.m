//
//  AppDelegate.m
//  BaseProject
//
//  Created by apple on 15/10/21.
//  Copyright © 2015年 Liangkai. All rights reserved.
//  APPKey:564da27d67e58e296b00021a

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "QiuShiViewController.h"
#import "LeftViewController.h"
#import "MeTableViewController.h"
#import "QiuShiBaiKeTabBarController.h"
#import "UMSocial.h"



//设置分享到QQ/Qzone的应用Id，和分享url 链接
#import "UMSocialQQHandler.h"
#import "UMSocialWechatHandler.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [self initializeWithApplication:application];
    
    //sina.564da27d67e58e296b00021a
    //设置友盟的APPkey
    [UMSocialData setAppKey:@"564da27d67e58e296b00021a"];
    
    //QQ授权登录
    [UMSocialQQHandler setQQWithAppId:@"1104539912" appKey:@"eFVgRits2fgf26Jf" url:@"http://www.umeng.com/social"];
    
    //设置微信AppId、appSecret，分享url
    [UMSocialWechatHandler setWXAppId:@"wxd930ea5d5a258f4f" appSecret:@"db426a9829e4b49a0dcac7b4162da6b6" url:@"http://www.qiushibaike.com"];
    
   



    
    self.window.rootViewController = self.sideMenu;
    
    [self configGlobalUIStyle]; //配置全局UI样式
    

    
   
    [self.window makeKeyAndVisible];
    
    return YES;
}




- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    BOOL result = [UMSocialSnsService handleOpenURL:url];
    if (result == FALSE) {
        //调用其他SDK，例如支付宝SDK等
    }
    return result;
}


//系统回调方法：
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return  [UMSocialSnsService handleOpenURL:url];
}


- (UITabBarController *)tabBarController{
    if (!_tabBarController) {
        _tabBarController = [[QiuShiBaiKeTabBarController alloc] init];
    }
    return _tabBarController;
}


/** 配置全局UI的样式 */
- (void)configGlobalUIStyle{
    /** 导航栏不透明 */
    [[UINavigationBar appearance] setTranslucent:NO];
    /** 设置导航栏背景图 */
//    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navigationbar_bg_64"] forBarMetrics:UIBarMetricsDefault];
    
    /** 配置导航栏题目的样式 */
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:kNaviTitleFontSize], NSForegroundColorAttributeName: kNaviTitleColor}];
    
    [[UITabBar appearance] setBackgroundColor:[UIColor whiteColor]];
}


/** 代码重构:用代码把功能实现以后，考虑代码结构如何编写可以更加方便后期维护 */
- (UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];

        [_window makeKeyAndVisible];
    }
    return _window;
}

- (RESideMenu *)sideMenu{
    if (!_sideMenu) {  //kVCFromSb(@"Me", @"Main")
        _sideMenu=[[RESideMenu alloc]initWithContentViewController:[QiuShiBaiKeTabBarController standardInstance] leftMenuViewController:kVCFromSb(@"Me", @"Main") rightMenuViewController:nil];
        //为sideMenu设置背景图,图片插件KSImageName，到Github下载
        _sideMenu.backgroundImage =[UIImage imageNamed:@"beijing1"];
        //可以让出现菜单时不显示状态栏
        _sideMenu.menuPrefersStatusBarHidden = YES;
        //不允许菜单栏到了边缘还可以继续缩小
        _sideMenu.bouncesHorizontally = NO;
    }
    return _sideMenu;
}

@end
