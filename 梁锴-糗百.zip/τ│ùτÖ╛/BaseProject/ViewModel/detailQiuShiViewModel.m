//
//  detailQiuShiViewModel.m
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "detailQiuShiViewModel.h"
#import "CommentsModel.h"
#import "CommentsManager.h"

@implementation detailQiuShiViewModel


- (instancetype)initWithID:(NSInteger)ID
{
    self = [super init];
    if (self) {
        self.ID = ID;
        
    }
    return self;
}

- (NSInteger)rowNumber
{
    return self.DataArray.count;
    
}
- (NSMutableArray *)DataArray {
    if(_DataArray == nil) {
        _DataArray = [[NSMutableArray alloc] init];
    }
    
    return _DataArray;
    
    
}

- (ItemsModel *)CommentsModelForRow:(NSInteger)row
{
    
    return self.DataArray[row];
    
}


//共同的方法
- (void)getDataCompleteHandle:(void(^)(NSError *error))complete
{
    [CommentsManager getCommentsID:_ID andCommentsPage:_page completionHandle:^(CommentsModel *model, NSError *error) {
        
        [self.DataArray addObjectsFromArray:model.items] ;
        complete (error);
        
    }];
    
}

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete
{
    _page += 1;
    
    [self getDataCompleteHandle:complete];
}
//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete
{
    _page += 1;
    [self getDataCompleteHandle:complete];
}


/** 头像icon */
- (NSString *)iconForRow:(NSInteger)row
{
    return  [self CommentsModelForRow:row].user.icon;
}

/** 名字login */
- (NSString *)loginForRow:(NSInteger)row
{
    return [self CommentsModelForRow:row].user.login;
}

/** 获得评论content */
-(NSString *)contentForRow:(NSInteger)row
{
    return [self CommentsModelForRow:row].content;
}

/** 第几条floor */

- (NSInteger)floorForRow:(NSInteger)row
{
    return [self CommentsModelForRow:row].floor;
}

@end
