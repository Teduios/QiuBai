//
//  detailQiuShiViewModel.h
//  BaseProject
//
//  Created by apple on 15/11/22.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseViewModel.h"

@interface detailQiuShiViewModel : BaseViewModel


@property(nonatomic)NSInteger rowNumber;

//分页加载,必须要有可变的数组
@property(nonatomic, strong)NSMutableArray *DataArray;

//页数
@property(nonatomic)NSInteger page;

@property (nonatomic)NSInteger ID;

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete;

//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete;


/** 头像icon */
- (NSString *)iconForRow:(NSInteger)row;

/** 名字login*/
- (NSString *)loginForRow:(NSInteger)row;

/** 获得评论content */
-(NSString *)contentForRow:(NSInteger)row;

/** 第几条floor */
- (NSInteger)floorForRow:(NSInteger)row;


- (instancetype)initWithID:(NSInteger)ID;


@end
