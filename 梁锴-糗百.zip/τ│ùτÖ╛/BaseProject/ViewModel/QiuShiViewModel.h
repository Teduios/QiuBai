//
//  QiuShiViewmodel.h
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseViewModel.h"
#import "QiuShiBaiKeNetManager.h"

@interface QiuShiViewModel : BaseViewModel

/** 必须使用此初始化方法，需要一个类型 */
- (id)initWithQiuShiListType:(QiuShiBaiKeListType)type;

@property (nonatomic) QiuShiBaiKeListType type;;

@property(nonatomic)NSInteger rowNumber;

//分页加载,必须要有可变的数组
@property(nonatomic, strong)NSMutableArray *dataArray;

//头部滚动栏, 图片数组
@property (nonatomic, strong)  NSArray *headImageURLs;



//页数
@property(nonatomic)NSInteger page;

//- (NSString *)contentForRow:(NSInteger)row;

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete;

//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete;

/** 头像 */
- (NSString *)iconForRow:(NSInteger)row;

/** 昵称 */
- (NSString *)nameForRow:(NSInteger)row;

/** 热门 */

/** 正文内容 */
- (NSString *)contentForRow:(NSInteger)row;

/** 正文图片 */
- (NSString *)contentIVForRow:(NSInteger)row;

/**评论数*/
- (NSString *)commentsNumberForRow:(NSInteger)row;

/** 分享数 */
- (NSString *)shareNumberForRow:(NSInteger)row;

/** 好笑数 */
- (NSString *)smileNumberForRow:(NSInteger)row;

/** 根据image属性 null是没有图 */
- (BOOL)containImages:(NSInteger)row;

/** 图片高度 */
- (NSNumber *)heightForRow:(NSInteger)row;


/** 视频内容 */
- (NSURL *)videoURLForRow:(NSInteger)row;

/** 视频内容图片 */
- (NSURL * )contentUrlForRow:(NSInteger)row;

/** 视频图片高度 */
- (NSNumber *)heightVideoForRow:(NSInteger)row;


/** 根据foramt属性 video是视频 */
- (BOOL)isVideoForRow:(NSInteger)row;

/** 获得每一条糗事的ID */
- (NSInteger)getIDForRow:(NSInteger)row;

@end
