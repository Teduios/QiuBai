//
//  FriendViewModel.h
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "BaseViewModel.h"

@interface FriendViewModel : BaseViewModel


@property(nonatomic)NSInteger rowNumber;

//分页加载,必须要有可变的数组
@property(nonatomic, strong)NSMutableArray *dataArray;

//页数
@property(nonatomic)NSInteger page;


//- (NSString *)contentForRow:(NSInteger)row;

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete;

//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete;

/** 头像 */
- (NSString *)iconIVForRow:(NSInteger)row;

/** 昵称 */
- (NSString *)nameLbForRow:(NSInteger)row;

/** 正文内容 */
- (NSString *)contentLbForRow:(NSInteger)row;

/** 正文图片 */
- (NSURL *)contentIVForRow:(NSInteger)row;
/** 位置 */
- (NSString *)locationForRow:(NSInteger)row;

/** 点赞 */
- (NSString *)likeCountForRow:(NSInteger)row;

/** 信息 */
- (NSString * )commentCountForRow:(NSInteger)row;

/** 性别 */
- (BOOL)isGender:(NSInteger)row;

/** 年龄 */
- (NSInteger)ageForRow:(NSInteger)row;

/** 是否有图片 */
- (BOOL) isHasImageForRow:(NSInteger)row;

@end
