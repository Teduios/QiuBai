//
//  FriendViewModel.m
//  BaseProject
//
//  Created by apple on 15/11/17.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "FriendViewModel.h"
#import "FriendModel.h"
#import "FriendNetManager.h"
@implementation FriendViewModel

- (NSInteger)rowNumber
{
    return self.dataArray.count;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (FriendDataModel *)FriendDataModelForRow:(NSInteger)row
{
    
    return self.dataArray[row];
    
}

/** 正文内容 */
- (NSString *)contentLbForRow:(NSInteger)row
{
    return [self FriendDataModelForRow:row].content;
}


/** 头像 */
- (NSString *)iconIVForRow:(NSInteger)row
{
    return [self FriendDataModelForRow:row].user.icon;
}

/** 昵称 */
- (NSString *)nameLbForRow:(NSInteger)row
{
    return [self FriendDataModelForRow:row].user.login;
}

/** 位置 */
- (NSString *)locationForRow:(NSInteger)row
{
     return [self FriendDataModelForRow:row].loaction;
}

/** 点赞 */
- (NSString *)likeCountForRow:(NSInteger)row
{
     return [NSString stringWithFormat:@"%ld",[self FriendDataModelForRow:row].like_count];
}

/** 信息 */
- (NSString * )commentCountForRow:(NSInteger)row
{
     return [NSString stringWithFormat:@"%ld",[self FriendDataModelForRow:row].comment_count];
}


//共同的方法
- (void)getDataCompleteHandle:(void(^)(NSError *error))complete
{
    [FriendNetManager getFriendpage:_page completionHandle:^(FriendModel *model, NSError *error) {
//        _page = 1;
        
        [self.dataArray addObjectsFromArray:model.data];
        
        complete (error);
    }];
    
}

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete
{
    NSLog(@"刷新");
    _page += 1;
    
    [self getDataCompleteHandle:complete];
}
//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete
{
    
    _page += 1;
    
    [self getDataCompleteHandle:complete];
}


//* 正文图片
- (NSURL *)contentIVForRow:(NSInteger)row
{
    
    return [NSURL URLWithString:[self FriendDataModelForRow:row].pic_urls.firstObject.pic_url];
}

/** 性别,默认返回男 */
- (BOOL)isGender:(NSInteger)row
{
    return [[self FriendDataModelForRow:row].user.gender isEqualToString:@"M"];
}

/** 年龄 */
- (NSInteger)ageForRow:(NSInteger)row
{
    return [self FriendDataModelForRow:row].user.age;
}

/** 是否有图片 */
- (BOOL)isHasImageForRow:(NSInteger)row
{
    return [self FriendDataModelForRow:row].pic_urls == nil;
}


@end
