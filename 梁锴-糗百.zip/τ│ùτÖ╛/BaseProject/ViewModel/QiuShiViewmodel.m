//
//  QiuShiViewmodel.m
//  BaseProject
//
//  Created by apple on 15/11/14.
//  Copyright © 2015年 Liangkai. All rights reserved.
//

#import "QiuShiViewModel.h"

@implementation QiuShiViewModel

- (id)initWithQiuShiListType:(QiuShiBaiKeListType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}

//预防性编程，防止没有使用initWithType初始化
- (id)init{
    if (self = [super init]) {
        //如果使用此方法初始化，那么崩溃提示
        NSAssert1(NO, @"%s 必须使用initWithType初始化", __func__);
    }
    return self;
}



- (NSInteger)rowNumber
{
    return self.dataArray.count;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    }
    return _dataArray;
}

- (QiushiBaiItemsKeModel *)QiuShiItemsListModelForRow:(NSInteger)row
{
    
    return self.dataArray[row];
    
}


/** 正文内容 */
- (NSString *)contentForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].content;
}

/** 正文图片 */
- (NSString *)contentIVForRow:(NSInteger)row
{
    return  [NSString stringWithFormat:@"http://pic.qiushibaike.com/system/pictures/%5ld/%ld/medium/%@",[self QiuShiItemsListModelForRow:row].ID/10000,[self QiuShiItemsListModelForRow:row].ID, [self QiuShiItemsListModelForRow:row].image];
}

/** 根据image属性  null是没有图 */
- (BOOL)containImages:(NSInteger)row{
    

    return [self QiuShiItemsListModelForRow:row].image == NULL;
}

/** 根据foramt属性 video是视频 */
- (BOOL)isVideoForRow:(NSInteger)row
{
    return [[self QiuShiItemsListModelForRow:row].format isEqualToString:@"video"];
}

/** 头像 */
- (NSString *)iconForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].user.icon;
}

/** 昵称 */
- (NSString *)nameForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].user.login;
}
/**评论数*/
- (NSString *)commentsNumberForRow:(NSInteger)row
{
    return [NSString stringWithFormat:@"评论%ld",[self QiuShiItemsListModelForRow:row].comments_count];
}

/** 分享数 */
- (NSString *)shareNumberForRow:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",[self QiuShiItemsListModelForRow:row].share_count];;
}

/** 图片高度 */
- (NSNumber * )heightForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].image_size.m.firstObject;
}


/** 好笑数 */
- (NSString *)smileNumberForRow:(NSInteger)row
{
    return [NSString stringWithFormat:@"好笑 %ld",[self QiuShiItemsListModelForRow:row].votes.up];
}

/** 视频内容图片 */
- (NSURL * )contentUrlForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self QiuShiItemsListModelForRow:row].pic_url];
}

/** 视频图片高度 */
- (NSNumber *)heightVideoForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].pic_size.firstObject;
}


/** 视频内容 */
- (NSURL *)videoURLForRow:(NSInteger)row
{
    return [NSURL URLWithString:[self QiuShiItemsListModelForRow:row].high_url];
}

/** 获得每一条糗事的ID */
- (NSInteger)getIDForRow:(NSInteger)row
{
    return [self QiuShiItemsListModelForRow:row].ID;
}

//共同的方法
- (void)getDataCompleteHandle:(void(^)(NSError *error))complete
{

    [QiuShiBaiKeNetManager getQiuShiBaiKeListType:_type page:_page completionHandle:^(QiushiBaiKeModel *model, NSError *error) {
        if (!error) {
            if (_page == 1) {
    
                [self.dataArr removeAllObjects];
            }
            if (self.dataArr.count>0) {
                
                NSIndexSet *indexSet = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, model.items.count)];
                [self.dataArr insertObjects:model.items atIndexes:indexSet];
                
            }else{
                [self.dataArray addObjectsFromArray:model.items];
            }
        }
        complete (error);
        
    }];
    
}

//刷新
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete
{
    NSLog(@"刷新");
    _page += 1;
    
    [self getDataCompleteHandle:complete];
    
}
//加载更多
- (void)getMoreCompleteHandle:(void(^)(NSError *error))complete
{
    
    _page += 1;
    
    NSLog(@"上拉刷新");
    
    [self getDataCompleteHandle:complete];
}




@end
